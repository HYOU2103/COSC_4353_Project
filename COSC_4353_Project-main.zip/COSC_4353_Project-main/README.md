# COSC_4353_Project
## Team Name: Thunder Bay


Haitham Yousif 

David Eldridge 

Joseph Gonzales 

Andres Elias Meraz 

